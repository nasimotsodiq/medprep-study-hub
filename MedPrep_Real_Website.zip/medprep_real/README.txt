MedPrep Study Hub starter real-website package

This version contains a responsive dashboard, timetable, roadmap, CBT quiz, daily progress tracker and PIN gate.

Current demo PIN: 2027

IMPORTANT: The PIN is still client-side in this starter. For real public security, deploy a backend authentication service and never store the secret PIN in browser JavaScript.

Next production upgrades: server-side login, individual student accounts, admin question upload, database progress, more CBT questions, results history, and secure hosting.
